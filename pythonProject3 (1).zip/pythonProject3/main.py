import random
import pygame
import time

pygame.init()


class Settings:
    is_shoot = False
    is_game_active = True
    is_menu_active = False
    score = 0
    health = 3
    f1 = pygame.font.Font(None, 90)
    f2 = pygame.font.Font(None, 36)
    f3 = pygame.font.Font(None, 180)
    lvl = int(open("lvl.txt").read()[0])


class Health:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.my_image = None
        self.has_image = False

    def add_image(self, path_to_image):
        self.my_image = pygame.transform.scale(pygame.image.load(path_to_image), (50, 50))

    def draw(self, screen1):
        screen1.blit(self.my_image, (self.x, self.y))


class Projectile:
    def __init__(self, x, y, lvl):
        self.x = x
        self.y = y
        self.speed = 3 * lvl / 2
        self.my_image = None

    def add_image(self, path_to_image):
        self.my_image = pygame.image.load(path_to_image)
        self.my_image = pygame.transform.scale(self.my_image, (100, 100))

    def rotate(self, degree):
        self.my_image = pygame.transform.rotate(self.my_image, degree)

    def draw(self, screen):
        screen.blit(self.my_image, (self.x, self.y))

    def check_collision(self, enemy_collision_list, projectile_list):
        for enemy_collision in enemy_collision_list:
            for projectile_collision in projectile_list:

                if enemy_collision.x <= projectile_collision.x + 100 <= enemy_collision.x + 100:
                    if enemy_collision.y <= projectile_collision.y <= enemy_collision.y + 100:
                        if type(enemy_collision) is Hero:
                            projectile_list.remove(projectile_collision)
                            Settings.health -= 1
                            healths.pop(-1)
                            exp = Explosion(hero.x, hero.y)
                            exps.append(exp)
                            pygame.mixer.music.load("sound2.mp3")
                            pygame.mixer.music.play()
                        else:
                            projectile_list.remove(projectile_collision)
                            if type(enemy_collision) is Enemy:
                                exp = Explosion(enemy_collision.x, enemy_collision.y)
                                exps.append(exp)
                                pygame.mixer.music.load("sound2.mp3")
                                pygame.mixer.music.play()
                                enemy_collision_list.remove(enemy_collision)
                                Settings.score += 100
                            if type(enemy_collision) is Boss:
                                exp = Explosion(enemy_collision.x, enemy_collision.y)
                                exps.append(exp)
                                pygame.mixer.music.load("sound2.mp3")
                                pygame.mixer.music.play()
                                enemy_collision.hp -= 1

    def move_up(self):
        self.y -= self.speed

    def move_down(self):
        self.y += self.speed * 3


class Boss:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.hp = 15
        self.speed = 3
        self.my_image = None
        self.napravlenie = "right"

    def add_image(self, path_to_image):
        self.my_image = pygame.transform.scale(pygame.image.load(path_to_image), (100, 100))

    def draw(self, screen):
        screen.blit(self.my_image, (self.x, self.y))

    def check(self):
        if self.x >= 1820:
            self.napravlenie = "left"
            self.y += self.speed * 6
        if self.x <= 0:
            self.napravlenie = "right"

    def move_left(self):
        self.x -= self.speed

    def move_right(self):
        self.x += self.speed

    def shoot(self):
        enemy_projectile = Projectile(self.x + 25, self.y + 20, Settings.lvl)
        enemy_projectile.add_image("projectile.png")
        enemy_projectile.rotate(240)
        return enemy_projectile


class Enemy:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.speed = 3
        self.my_image = None
        self.left = False
        self.right = True
        self.napravlenie = "right"
        self.way_left = 0
        self.way_right = 0

    def add_image(self, path_to_image):
        self.my_image = pygame.transform.scale(pygame.image.load(path_to_image), (100, 100))

    def draw(self, function_screen):
        function_screen.blit(self.my_image, (self.x, self.y))

    def check(self):
        if self.way_right >= 80:
            self.napravlenie = "left"
            self.move_down()
        if self.way_left >= 50:
            self.napravlenie = "right"

    def move_left(self):
        self.x -= self.speed
        self.way_left += self.speed
        self.way_right -= self.speed

    def move_right(self):
        self.x += self.speed
        self.way_left -= self.speed
        self.way_right += self.speed

    def move_down(self):
        self.y += self.speed * 3

    def shoot(self):
        enemy_projectile = Projectile(self.x + 25, self.y + 20, Settings.lvl)
        enemy_projectile.add_image("projectile.png")
        enemy_projectile.rotate(240)
        return enemy_projectile


class Hero:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.speed = 10
        self.my_image = pygame.transform.scale(pygame.image.load('pngegg.png'), (100, 100))

    def draw(self, function_screen):
        function_screen.blit(self.my_image, (self.x, self.y))

    def move_left(self):
        if self.x > 0:
            self.x -= self.speed

    def move_right(self):
        if self.x < 1870:
            self.x += self.speed


class Explosion:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.size = 5

    def draw(self, screen):
        pygame.draw.rect(screen, (255, 0, 0), (self.x, self.y, self.size, self.size))
        self.size += 4
        self.x -= 2
        self.y -= 2


def main_menu(screen_function):
    selected = 'start'
    while Settings.is_menu_active:
        screen.fill(blue)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                quit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    Settings.is_menu_active = False

                if event.key == pygame.K_DOWN:
                    if selected == 'start':
                        selected = 'quit'
                    elif selected == 'quit':
                        selected = 'shop'
                    elif selected == 'shop':
                        selected = 'start'

                if event.key == pygame.K_UP:
                    if selected == 'start':
                        selected = 'shop'
                    elif selected == 'quit':
                        selected = 'start'
                    elif selected == 'shop':
                        selected = 'quit'

                if event.key == pygame.K_RETURN:
                    if selected == 'start':
                        Settings.is_menu_active = False
                    elif selected == 'quit':
                        quit()
                    elif selected == 'shop':
                        shop_menu()

        if selected == 'start':
            title_text = Settings.f3.render('Space shooter', True, red)
            start_text = Settings.f1.render('Играть', True, white)
            quit_text = Settings.f1.render('Выйти', True, black)
            shop_text = Settings.f1.render('Магазин', True, black)
        if selected == 'quit':
            title_text = Settings.f3.render('Space shooter', True, red)
            start_text = Settings.f1.render('Играть', True, black)
            quit_text = Settings.f1.render('Выйти', True, white)
            shop_text = Settings.f1.render('Магазин', True, black)
        if selected == 'shop':
            title_text = Settings.f3.render('Space shooter', True, red)
            start_text = Settings.f1.render('Играть', True, black)
            quit_text = Settings.f1.render('Выйти', True, black)
            shop_text = Settings.f1.render('Магазин', True, white)

        screen.blit(title_text, (500, 100))
        screen.blit(start_text, (700, 300))
        screen.blit(quit_text, (700, 500))
        screen.blit(shop_text, (700, 700))
        clock.tick(60)
        pygame.display.update()


def shop_menu():
    selected = 'quit'
    while Settings.is_menu_active:
        screen.fill(blue)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                quit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    Settings.is_menu_active = False

                if event.key == pygame.K_DOWN:
                    if selected == 'quit':
                        selected = 'health'
                    elif selected == 'health':
                        selected = 'skin1'
                    elif selected == 'skin1':
                        selected = 'skin2'
                    elif selected == 'skin2':
                        selected = 'speed'
                    elif selected == 'speed':
                        selected = 'quit'

                if event.key == pygame.K_UP:
                    if selected == 'quit':
                        selected = 'speed'
                    elif selected == 'health':
                        selected = 'quit'
                    elif selected == 'skin1':
                        selected = 'health'
                    elif selected == 'skin2':
                        selected = 'skin1'
                    elif selected == 'speed':
                        selected = 'skin2'

                if event.key == pygame.K_RETURN:
                    if selected == 'quit':
                        break
                    elif selected == 'health' and Settings.score >= 100:
                        Settings.health += 1
                        health = Health(len(healths) * 60, 0)
                        health.add_image('pngegg.png')
                        healths.append(health)
                        Settings.score -= 100
                    elif selected == 'skin1' and Settings.score >= 500:
                        hero.add_image("ship.png")
                        Settings.score -= 500
                    elif selected == 'skin2' and Settings.score >= 500:
                        hero.add_image("ship2.png")
                        Settings.score -= 500
                    elif selected == "speed" and Settings.score >= 100:
                        hero.speed += 1
                        Settings.score -= 100

        if selected == 'quit':
            quit_text = Settings.f1.render('Выйти', True, white)
            health_text = Settings.f1.render('Хп', True, black)
            skin1_text = Settings.f1.render('Скин1', True, black)
            skin2_text = Settings.f1.render('Скин2', True, black)
            speed_text = Settings.f1.render('Скорость', True, black)
        if selected == 'health':
            quit_text = Settings.f1.render('Выйти', True, black)
            health_text = Settings.f1.render('Хп', True, white)
            skin1_text = Settings.f1.render('Скин1', True, black)
            skin2_text = Settings.f1.render('Скин2', True, black)
            speed_text = Settings.f1.render('Скорость', True, black)
        if selected == 'skin1':
            quit_text = Settings.f1.render('Выйти', True, black)
            health_text = Settings.f1.render('Хп', True, black)
            skin1_text = Settings.f1.render('Скин1', True, white)
            skin2_text = Settings.f1.render('Скин2', True, black)
            speed_text = Settings.f1.render('Скорость', True, black)
        if selected == 'skin2':
            quit_text = Settings.f1.render('Выйти', True, black)
            health_text = Settings.f1.render('Хп', True, black)
            skin1_text = Settings.f1.render('Скин1', True, black)
            skin2_text = Settings.f1.render('Скин2', True, white)
            speed_text = Settings.f1.render('Скорость', True, black)
        if selected == 'speed':
            quit_text = Settings.f1.render('Выйти', True, black)
            health_text = Settings.f1.render('Хп', True, black)
            skin1_text = Settings.f1.render('Скин1', True, black)
            skin2_text = Settings.f1.render('Скин2', True, black)
            speed_text = Settings.f1.render('Скорость', True, white)

        screen.blit(quit_text, (700, 100))
        screen.blit(health_text, (700, 300))
        screen.blit(skin1_text, (700, 500))
        screen.blit(skin2_text, (700, 700))
        screen.blit(speed_text, (700, 900))
        clock.tick(60)
        pygame.display.update()


hero = Hero(0, 950)

clock = pygame.time.Clock()
screen = pygame.display.set_mode((1920, 1080))

black = (0, 0, 0)
white = (255, 255, 255)
red = (255, 0, 0)
lime = (0, 255, 0)
blue = (0, 0, 255)

exps = list()
healths = list()
vragi = []
for health_i in range(Settings.health):
    health = Health(health_i * 60, 0)
    health.add_image("pngegg.png")
    healths.append(health)


def read_lvl():
    a = Settings.lvl
    b = open(str(a) + ".txt")
    lines = b.readlines()
    for i in range(len(lines)):
        for i2 in range(len(lines[i])):
            if lines[i][i2] == "x":
                vragi.append((i2, i))


def game():

    is_right = False
    is_left = False
    is_game_active = True
    pygame.mixer.init()

    enemies = list()
    projectiles = list()
    enemy_projectiles = list()
    bosses = list()
    heroes = list()

    score = 0
    read_lvl()
    f4 = pygame.font.Font(None, 90)
    game_over_text = f4.render('Вы проиграли', True, red)
    win = f4.render('Вы выиграли', True, lime)

    Settings.is_menu_active = True
    main_menu(screen)

    heroes.append(hero)
    for i in range(14):
        for j in range(4):
            if (i, j) in vragi:
                enemy = Enemy(50 + i * 130, 100 + j * 130)
                enemy.add_image('pngegg1.png')
                enemies.append(enemy)

    while is_game_active:
        screen.fill(black)

        text1 = Settings.f2.render('Счёт:' + str(Settings.score), True, red)
        screen.blit(text1, (1600, 30))

        # действия со всеми объектами
        for enemy1 in enemies:
            enemy1.draw(screen)
            enemy1.check()
            if enemy1.napravlenie == "left":
                enemy1.move_left()
            else:
                enemy1.move_right()
            a = random.randint(0, 1000)
            if a == 0:
                enemy_projectiles.append(enemy1.shoot())
            if enemy1.y > 1040:
                screen.fill(black)
                screen.blit(game_over_text, (750, 450))
                pygame.display.update()
                time.sleep(5)
                quit()
        for boss1 in bosses:
            print(boss1.hp)
            boss1.draw(screen)
            boss1.check()
            if boss1.napravlenie == "left":
                boss1.move_left()
            else:
                boss1.move_right()
            a = random.randint(0, 20)
            if a == 0:
                enemy_projectiles.append(boss1.shoot())
            if boss1.hp == 0:
                bosses.remove(boss1)
                screen.fill(black)
                screen.blit(win, (750, 450))
                pygame.display.update()
                time.sleep(1)
                Settings.lvl += 1
                a = open("lvl.txt", "w")
                a.write(str(Settings.lvl))
                b = open("lvl.txt")
                lines = b.read()
                if lines == "6":
                    b = open("lvl.txt", "w")
                    b.write("1")
                quit()
        for projectile1 in projectiles:
            projectile1.draw(screen)
            projectile1.move_up()
            projectile1.check_collision(enemies, projectiles)
            projectile1.check_collision(bosses, projectiles)
        for exp in exps:
            if exp.size < 100:
                exp.draw(screen)
            else:
                exps.remove(exp)
        for projectile1 in enemy_projectiles:
            projectile1.draw(screen)
            projectile1.move_down()
            projectile1.check_collision(heroes, enemy_projectiles)
        for health1 in healths:
            health1.draw(screen)
        if is_left:
            hero.move_left()
        if is_right:
            hero.move_right()
        hero.draw(screen)
        # клавиши
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                quit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    is_left = True
                if event.key == pygame.K_RIGHT:
                    is_right = True
                if event.key == pygame.K_ESCAPE:
                    Settings.is_menu_active = True
                    main_menu(screen)
                if event.key == pygame.K_SPACE:
                    projectile = Projectile(hero.x - 10, hero.y - 70, 2)
                    projectile.add_image('projectile.png')
                    projectile.rotate(57)
                    projectiles.append(projectile)
                    pygame.mixer.music.load("sound.mp3")
                    pygame.mixer.music.play()

            if event.type == pygame.KEYUP:
                if event.key == pygame.K_LEFT:
                    is_left = False
                if event.key == pygame.K_RIGHT:
                    is_right = False

        if len(enemies) == 0 and len(bosses) == 0:
            boss = Boss(0, 0)
            boss.add_image("pngegg.png")
            bosses.append(boss)
        if Settings.health == 0:
            screen.fill(black)
            screen.blit(game_over_text, (750, 450))
            pygame.display.update()
            time.sleep(5)
            quit()
        clock.tick(60)
        pygame.display.update()
game()